import React, { createContext } from "react";

const AuthContext = createContext();

const AuthProvider = ({ Children }) => {
  return (
    <AuthContext.Provider value={{ usuario: "Marcelo" }}>
      {Children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
